%Keluarga berjenis kelamin laki-laki

laki(liwang).
laki(syamsuddin).
laki(ronal).
laki(widin).
laki(wisdar).
laki(resky).
laki(irfandi).
laki(irsandi).

%Keluarga berjenis kelamin perempuan

perempuan(sugi).
perempuan(hamsinah).
perempuan(tommi).
perempuan(reni).
perempuan(elin).
perempuan(wiwi).
perempuan(winni).
perempuan(irfani).

%Orang tua dari masing-masing anak

orangtua(liwang,hamsinah).
orangtua(sugi,hamsinah).
orangtua(liwang,tommi).
orangtua(sugi,tommi).
orangtua(syamsuddin,reni).
orangtua(hamsinah,reni).
orangtua(syamsuddin,ronal).
orangtua(hamsinah,ronal).
orangtua(syamsuddin,elin).
orangtua(hamsinah,elin).
orangtua(syamsuddin,resky).
orangtua(hamsinah,resky).
orangtua(tommi,wiwi).
orangtua(tommi,widin).
orangtua(tommi,winni).
orangtua(tommi,wisdar).
orangtua(tene,irfandi).
orangtua(tene,irsandi).
orangtua(tene,irfani).


%Query untuk mencari anggota keluarga dalam silsilah


ibu(A,B):-orangtua(A,B),perempuan(A).
ayah(A,B):-orangtua(A,B),laki(A).

anak(A,B):-orangtua(A,B).
anaklaki_laki(A,B):-orangtua(A,B),laki(A).
anakperempuan(A,B):-orangtua(A,B),perempuan(A).

menikah(A,B):-anak(S,Y),anak(S,X),laki(Y).
istri(B,A):-anak(S,Y),anak(S,X),perempuan(X).
suami(B,A):-anak(S,Y),anak(S,X),laki(Y).

kakek(Y,Z):-orangtua(A,B),orangtua(B,A),perempuan(X).
nenek(Y,Z):-ibu(A,B),ibu(K,L).

saudara(K,L):-anak(Y,Z),anak(Y,Z).
saudaraperempuan(K,L):-anak(C,M),anak(M,C),perempuan(X).
saudaraperempuan(K,L):-anak(C,M),anak(M,C),perempuan(X).

bibi(K,L):-saudara(A,B),orangtua(Y,Z),perempuan(X),not(ayah(A,B)).
bibi(K,L):-saudara(A,B),orangtua(Y,Z),perempuan(X),not(ayah(A,B)).

cuculaki(O,N):-anak(N,O),orangtua(K,L),laki(Y).
cucuperempuan(O,N):-anak(N,O),orangtua(K,L),perempuan(X).
